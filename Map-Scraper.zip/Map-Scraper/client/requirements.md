## Packages
framer-motion | For smooth animations and transitions
lucide-react | Beautiful icons
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
The backend provides scraping capabilities.
Polling might be needed for the scrape status if websockets aren't available (schema suggests 'pending'/'completed' status).
